-- ============================================
-- DATABASE BACKUP
-- Created: 2026-07-02 09:32:07
-- Tables: 42
-- ============================================

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `admin_notifications`;
CREATE TABLE `admin_notifications` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `type` enum('order','delivery','payment','product','user','system','alert') DEFAULT 'system',
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`notification_id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_is_read` (`is_read`),
  KEY `idx_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `backup_logs`;
CREATE TABLE `backup_logs` (
  `backup_id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_name` varchar(255) NOT NULL,
  `backup_type` enum('database','files','full') NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` varchar(50) DEFAULT NULL,
  `status` enum('pending','running','completed','failed') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`backup_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `backup_logs` VALUES
('3', 'backup_2026-06-21_18-32-25.sql', 'database', '../backups/backup_2026-06-21_18-32-25.sql', '83.58 KB', 'completed', NULL, '1', '2026-06-21 19:32:25', '2026-06-21 19:32:25'),
('4', 'backup_2026-06-21_19-44-00.sql', 'database', '../../backups/backup_2026-06-21_19-44-00.sql', '88.33 KB', 'completed', NULL, '1', '2026-06-21 20:44:01', '2026-06-21 20:44:01'),
('5', 'backup_2026-06-29_09-27-22.sql', 'database', '../../backups/backup_2026-06-29_09-27-22.sql', '80.40 KB', 'completed', NULL, '1', '2026-06-29 10:27:23', '2026-06-29 10:27:23'),
('6', 'backup_2026-06-29_09-43-20.zip', 'full', '../../backups/backup_2026-06-29_09-43-20.zip', '15.42 KB', 'completed', NULL, '1', '2026-06-29 10:43:21', '2026-06-29 10:43:21'),
('7', 'backup_2026-06-29_09-45-28.zip', 'full', '../../backups/backup_2026-06-29_09-45-28.zip', '15.45 KB', 'completed', NULL, '1', '2026-06-29 10:45:28', '2026-06-29 10:45:28'),
('8', 'backup_2026-06-29_09-58-19.zip', 'full', 'C:\\xampp\\htdocs\\UNK-System2\\admin\\settings/../../backups/backup_2026-06-29_09-58-19.zip', '15.47 KB', 'completed', NULL, '1', '2026-06-29 10:58:20', '2026-06-29 10:58:20'),
('9', 'backup_2026-06-29_09-59-30.zip', 'full', 'C:\\xampp\\htdocs\\UNK-System2\\admin\\settings/../../backups/backup_2026-06-29_09-59-30.zip', '15.53 KB', 'completed', NULL, '1', '2026-06-29 10:59:30', '2026-06-29 10:59:30'),
('10', 'backup_2026-06-29_09-59-37.zip', 'full', 'C:\\xampp\\htdocs\\UNK-System2\\admin\\settings/../../backups/backup_2026-06-29_09-59-37.zip', '15.56 KB', 'completed', NULL, '1', '2026-06-29 10:59:38', '2026-06-29 10:59:38'),
('11', 'backup_2026-06-29_09-59-43.zip', 'full', 'C:\\xampp\\htdocs\\UNK-System2\\admin\\settings/../../backups/backup_2026-06-29_09-59-43.zip', '15.58 KB', 'completed', NULL, '1', '2026-06-29 10:59:43', '2026-06-29 10:59:43'),
('12', 'backup_2026-06-29_09-59-58.zip', 'full', 'C:\\xampp\\htdocs\\UNK-System2\\admin\\settings/../../backups/backup_2026-06-29_09-59-58.zip', '15.57 KB', 'completed', NULL, '1', '2026-06-29 10:59:58', '2026-06-29 10:59:58'),
('13', 'backup_2026-07-02_09-28-30.zip', 'full', 'C:\\xampp\\htdocs\\UNK-System2\\admin\\settings/../../backups/backup_2026-07-02_09-28-30.zip', '16.42 KB', 'completed', NULL, '1', '2026-07-02 10:28:35', '2026-07-02 10:28:35');

DROP TABLE IF EXISTS `business_notifications`;
CREATE TABLE `business_notifications` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('order','inventory','review','payment','system') DEFAULT 'system',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`notification_id`),
  KEY `idx_biz_notif_business` (`business_id`),
  KEY `idx_biz_notif_type` (`type`),
  KEY `idx_biz_notif_read` (`is_read`),
  CONSTRAINT `fk_biz_notif_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`business_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `business_notifications` VALUES
('29', '7', 'New Order', 'Order #48 from Twaha Mohamed - TSh 954,000', 'order', '1', '2026-06-10 11:35:37'),
('30', '7', 'Order Status Updated', 'Order #48 status changed from Pending to Accepted.', 'order', '1', '2026-06-11 18:51:04'),
('31', '7', 'Order Status Updated', 'Order #48 status changed from Accepted to Confirmed.', 'order', '1', '2026-06-11 21:58:57'),
('32', '7', 'Order Status Updated', 'Order #48 status changed from Confirmed to Preparing.', 'order', '1', '2026-06-11 21:59:17'),
('33', '7', 'Payment Status Updated', 'Order 48 payment status changed from Pending to Paid.', 'payment', '1', '2026-06-11 22:02:37'),
('34', '7', 'Payment Status Updated', 'Order 48 payment status changed from Paid to Pending.', 'payment', '1', '2026-06-11 22:04:21'),
('35', '7', 'Payment Status Updated', 'Order 48 payment status changed from Pending to Paid.', 'payment', '1', '2026-06-11 22:34:56'),
('36', '11', 'New Order', 'Order #49 from samsung ultra - TSh 28,000', 'order', '0', '2026-06-12 12:03:41'),
('37', '11', 'New Order', 'Order #50 from samsung ultra - TSh 75,000', 'order', '0', '2026-06-12 12:05:14'),
('38', '11', 'New Order', 'Order #51 from samsung ultra - TSh 53,000', 'order', '0', '2026-06-12 12:07:49'),
('39', '7', 'Order Status Updated', 'Order 48 status changed from Confirmed to Preparing.', 'order', '1', '2026-06-12 12:10:57'),
('40', '7', 'Order Status Updated', 'Order 48 status changed from Preparing to Ready.', 'order', '1', '2026-06-12 12:11:10'),
('41', '11', 'New Order', 'Order #52 from Twaha Mohamed - TSh 50,000', 'order', '0', '2026-06-12 12:34:26'),
('42', '11', 'New Order', 'Order #53 from Twaha Mohamed - TSh 40,000', 'order', '0', '2026-06-12 12:35:00'),
('44', '7', 'Order Status Updated', 'Order 54 status changed from Pending to Accepted.', 'order', '1', '2026-06-12 12:36:44'),
('45', '7', 'Order Status Updated', 'Order 54 status changed from Accepted to Confirmed.', 'order', '1', '2026-06-12 12:36:54'),
('46', '7', 'Order Status Updated', 'Order 54 status changed from Confirmed to Preparing.', 'order', '1', '2026-06-12 12:37:11'),
('47', '7', 'Order Status Updated', 'Order 54 status changed from Confirmed to Preparing.', 'order', '1', '2026-06-12 12:42:17'),
('48', '7', 'Order Status Updated', 'Order 54 status changed from Preparing to Ready.', 'order', '1', '2026-06-12 12:42:29'),
('49', '11', 'Order Status Updated', 'Order 53 status changed from Pending to Accepted.', 'order', '0', '2026-06-13 00:01:36'),
('50', '11', 'Order Status Updated', 'Order 53 status changed from Accepted to Confirmed.', 'order', '0', '2026-06-13 00:01:44'),
('51', '11', 'Order Status Updated', 'Order 53 status changed from Confirmed to Preparing.', 'order', '0', '2026-06-13 00:01:51'),
('52', '11', 'Order Status Updated', 'Order 52 status changed from Pending to Accepted.', 'order', '0', '2026-06-13 00:02:06'),
('53', '11', 'Order Status Updated', 'Order 52 status changed from Accepted to Confirmed.', 'order', '0', '2026-06-13 00:02:15'),
('54', '11', 'Order Status Updated', 'Order 52 status changed from Confirmed to Preparing.', 'order', '0', '2026-06-13 00:02:22'),
('55', '11', 'Stock Updated', 'Product \'OIP women watch\' stock changed from 9 to 15. Reason: stock adjustment', 'inventory', '0', '2026-06-18 23:46:31'),
('56', '10', 'New Order', 'Order #55 from Twaha Mohamed - TSh 275,000', 'order', '1', '2026-06-19 15:37:50'),
('57', '11', 'New Order', 'Order #56 from Twaha Mohamed - TSh 30,000', 'order', '0', '2026-06-19 15:37:51'),
('58', '10', 'Order Status Updated', 'Order 55 status changed from Pending to Accepted. Note: accept', 'order', '1', '2026-06-19 15:44:09'),
('59', '10', 'Order Status Updated', 'Order 55 status changed from Accepted to Confirmed.', 'order', '1', '2026-06-19 15:44:22'),
('60', '10', 'Order Status Updated', 'Order 55 status changed from Confirmed to Preparing.', 'order', '1', '2026-06-19 15:44:40'),
('61', '10', 'Stock Updated', 'Product \'Hp pc\' stock changed from 12 to 13. Reason: stock adjustment', 'inventory', '1', '2026-06-20 09:49:16'),
('62', '11', 'New Order', 'Order #57 from Twaha Mohamed - TSh 53,000', 'order', '0', '2026-06-24 05:10:51'),
('63', '7', 'New Order', 'Order #58 from Twaha Mohamed - TSh 503,000', 'order', '1', '2026-06-26 19:28:01'),
('64', '7', 'Order Status Updated', 'Order 58 status changed from Pending to Accepted.', 'order', '1', '2026-06-29 14:11:27'),
('65', '7', 'Stock Updated', 'Product \'Dressings Table\' stock changed from 6 to 16. Reason: stock adjustment', 'inventory', '0', '2026-06-29 19:23:56'),
('66', '7', 'New Order', 'Order #59 from Twaha Mohamed - TSh 350,000', 'order', '0', '2026-06-30 01:10:35'),
('67', '7', 'New Order', 'Order #60 from Twaha Mohamed - TSh 182,000', 'order', '0', '2026-06-30 01:21:52'),
('68', '7', 'New Order', 'Order #61 from Twaha Mohamed - TSh 182,000', 'order', '0', '2026-06-30 03:02:35'),
('69', '11', 'New Order', 'Order #62 from Twaha Mohamed - TSh 32,000', 'order', '0', '2026-07-01 19:24:31'),
('70', '7', 'New Order', 'Order #63 from Twaha Mohamed - TSh 182,000', 'order', '0', '2026-07-01 19:34:15'),
('71', '7', 'New Order', 'Order #64 from Twaha Mohamed - TSh 182,000', 'order', '0', '2026-07-01 19:56:41'),
('72', '7', 'New Order', 'Order #65 from Twaha Mohamed - TSh 292,000', 'order', '0', '2026-07-01 20:01:09'),
('73', '11', 'New Order', 'Order #66 from Twaha Mohamed - TSh 42,000', 'order', '0', '2026-07-01 20:29:05');

DROP TABLE IF EXISTS `business_settings`;
CREATE TABLE `business_settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `notification_settings` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `uk_business_settings_business` (`business_id`),
  CONSTRAINT `fk_business_settings_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`business_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `businesses`;
CREATE TABLE `businesses` (
  `business_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `business_name` varchar(255) NOT NULL,
  `registration_number` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `address` text NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `license_number` varchar(100) DEFAULT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `business_hours` text DEFAULT NULL,
  `rating` decimal(2,1) DEFAULT 0.0,
  `total_reviews` int(11) DEFAULT 0,
  `is_verified` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `city` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `payment_methods` text DEFAULT NULL,
  `nida_number` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`business_id`),
  UNIQUE KEY `uk_businesses_user` (`user_id`),
  UNIQUE KEY `uk_businesses_registration` (`registration_number`),
  UNIQUE KEY `uk_businesses_nida` (`nida_number`),
  KEY `idx_businesses_name` (`business_name`),
  KEY `idx_businesses_verified` (`is_verified`),
  KEY `idx_businesses_active` (`is_active`),
  KEY `idx_businesses_city` (`city`),
  CONSTRAINT `fk_businesses_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `businesses` VALUES
('7', '19', 'Nyoni Collection', 'BLA-2024-00123', 'Welcome', 'Kariakoo', 'Kariakoo-Msimbazi', NULL, NULL, 'TIN-12345678', 'assets/uploads/businesses/1780414954_6a1ef9eab354b.jpeg', 'Monday-Saturday: 8am-8pm', '0.0', '0', '1', '1', '2026-06-01 00:32:03', 'Dar es Salaam', '0767708012', 'cash,mobile_money', '19871104171020000120'),
('10', '28', 'Mquraysh Tech', 'BLA-2024-00130', 'Welcome', 'Kariakoo', 'Kariakoo-Msimbazi', NULL, NULL, 'TIN-12345630', 'assets/uploads/businesses/1781815352_6a34583817335.jpg', 'Monday-Saturday: 8am-8pm', '0.0', '0', '1', '1', '2026-06-03 03:22:59', 'Dar es Salaam', '0799051862', 'cash,mobile_money', '20041104171020000120'),
('11', '31', 'Fashion shop', 'BLA-2026-00123', 'WELCOME', 'kariakoo', 'Kariakoo-Msimbazi', NULL, NULL, 'TIN-12345', 'assets/uploads/businesses/1781822754_6a347522b2af7.jpg', 'Monday-Saturday: 8am-8pm', '0.0', '0', '1', '1', '2026-06-10 16:26:43', 'Dar es Salaam', '0764080102', 'cash', '20071104171020000120');

DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`cart_id`),
  UNIQUE KEY `uk_cart_customer_product` (`customer_id`,`product_id`),
  KEY `idx_cart_customer` (`customer_id`),
  KEY `idx_cart_product` (`product_id`),
  CONSTRAINT `fk_cart_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_cart_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`category_id`),
  KEY `idx_categories_parent` (`parent_id`),
  KEY `idx_categories_active` (`is_active`),
  CONSTRAINT `fk_categories_parent` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`category_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `categories` VALUES
('1', 'Electronics', 'Smartphones, laptops, TVs, audio devices, cameras, and accessories.', NULL, '1', '2026-05-26 18:29:35', '1'),
('2', 'Fashion & Clothing', 'Men’s, women’s, and children’s clothing, shoes, bags, jewelry, and watches.', NULL, '2', '2026-05-26 18:29:35', '1'),
('3', 'Home & Living', 'Furniture, kitchenware, home decor, bedding, appliances, and DIY tools.', NULL, '3', '2026-05-26 18:29:35', '1'),
('4', 'Food & Beverages', 'Fresh groceries, packaged foods, beverages, snacks, and bakery items.', NULL, '4', '2026-05-26 18:29:35', '1'),
('5', 'Health & Beauty', 'Skincare, makeup, hair care, fragrances, personal care, and supplements.', NULL, '5', '2026-05-26 18:29:35', '1'),
('6', 'Automotive', 'Car and motorcycle parts, accessories, tyres, and garage tools.', NULL, '6', '2026-05-26 18:29:35', '1'),
('7', 'Baby & Kids', 'Baby clothing, gear, diapers, toys, and baby food.', NULL, '7', '2026-05-26 18:29:35', '1'),
('8', 'Sports & Outdoors', 'Exercise equipment, outdoor gear, team sports, camping and hiking gear.', NULL, '8', '2026-05-26 18:29:35', '1'),
('9', 'Books & Stationery', 'School books, notebooks, writing instruments, art supplies, and office essentials.', NULL, '9', '2026-05-26 18:29:35', '1'),
('10', 'Services', 'Repair services (phones, electronics), tailoring, cleaning, delivery, IT support.', NULL, '10', '2026-05-26 18:29:35', '1'),
('67', 'Mobile Phones', 'Smartphones, feature phones, and mobile accessories', '1', '1', '2026-05-26 19:29:48', '1'),
('68', 'Laptops & Computers', 'Notebooks, desktops, tablets, and computer peripherals', '1', '2', '2026-05-26 19:29:48', '1'),
('69', 'Audio & Headphones', 'Headphones, earphones, speakers, and home audio systems', '1', '3', '2026-05-26 19:29:48', '1'),
('70', 'TV & Home Theatre', 'Televisions, projectors, soundbars, and home cinema systems', '1', '4', '2026-05-26 19:29:48', '1'),
('71', 'Cameras & Photography', 'DSLR, mirrorless cameras, lenses, tripods, and camera bags', '1', '5', '2026-05-26 19:29:48', '1'),
('72', 'Accessories & Cables', 'Chargers, power banks, cables, adapters, and screen protectors', '1', '6', '2026-05-26 19:29:48', '1'),
('73', 'Men\'s Clothing', 'Shirts, trousers, jeans, jackets, suits, and traditional wear', '2', '1', '2026-05-26 19:29:48', '1'),
('74', 'Women\'s Clothing', 'Dresses, blouses, skirts, trousers, hijabs, and traditional wear', '2', '2', '2026-05-26 19:29:48', '1'),
('75', 'Children\'s Clothing', 'Clothes for boys and girls of all ages (0-16 years)', '2', '3', '2026-05-27 02:29:48', '1'),
('76', 'Shoes', 'Sneakers, formal shoes, sandals, slippers, and boots for all genders', '2', '4', '2026-05-27 02:29:48', '1'),
('77', 'Bags & Luggage', 'Handbags, backpacks, travel bags, school bags, and wallets', '2', '5', '2026-05-27 02:29:48', '1'),
('78', 'Jewelry & Watches', 'Necklaces, rings, earrings, bracelets, and wristwatches', '2', '6', '2026-05-27 02:29:48', '1'),
('79', 'Furniture', 'Sofas, beds, tables, chairs, wardrobes, and office furniture', '3', '1', '2026-05-27 02:29:48', '1'),
('80', 'Kitchen & Dining', 'Cookware, utensils, dinner sets, glassware, and kitchen appliances', '3', '2', '2026-05-27 02:29:48', '1'),
('81', 'Bedding & Bath', 'Bed sheets, blankets, pillows, towels, and bathroom accessories', '3', '3', '2026-05-27 02:29:48', '1'),
('82', 'Home Decor', 'Wall art, curtains, vases, candles, mirrors, and decorative items', '3', '4', '2026-05-27 02:29:48', '1'),
('83', 'Appliances', 'Refrigerators, microwaves, washing machines, fans, and air conditioners', '3', '5', '2026-05-27 02:29:48', '1'),
('84', 'Tools & DIY', 'Hand tools, power tools, paint, hardware, and home improvement supplies', '3', '6', '2026-05-27 02:29:48', '1'),
('85', 'Fresh Fruits & Vegetables', 'Locally grown and imported fresh produce', '4', '1', '2026-05-27 02:29:48', '1'),
('86', 'Meat & Seafood', 'Beef, chicken, goat, fish, and other seafood products', '4', '2', '2026-05-27 02:29:48', '1'),
('87', 'Dairy & Eggs', 'Milk, cheese, yoghurt, butter, and fresh eggs', '4', '3', '2026-05-27 02:29:48', '1'),
('88', 'Bakery', 'Bread, cakes, pastries, cookies, and baked snacks', '4', '4', '2026-05-27 02:29:48', '1'),
('89', 'Beverages', 'Soft drinks, juices, bottled water, tea, coffee, and energy drinks', '4', '5', '2026-05-27 02:29:48', '1'),
('90', 'Snacks & Sweets', 'Chips, biscuits, chocolates, candies, and traditional snacks', '4', '6', '2026-05-27 02:29:48', '1'),
('91', 'Skincare', 'Moisturizers, cleansers, serums, sunscreen, and face masks', '5', '1', '2026-05-27 02:29:48', '1'),
('92', 'Makeup', 'Foundation, lipstick, eyeshadow, mascara, and makeup tools', '5', '2', '2026-05-27 02:29:48', '1'),
('93', 'Hair Care', 'Shampoo, conditioner, oils, styling products, and hair tools', '5', '3', '2026-05-27 02:29:48', '1'),
('94', 'Fragrances', 'Perfumes, deodorants, and body sprays for men and women', '5', '4', '2026-05-27 02:29:48', '1'),
('95', 'Personal Care', 'Soap, toothpaste, razors, sanitary products, and hand sanitizers', '5', '5', '2026-05-27 02:29:48', '1'),
('96', 'Vitamins & Supplements', 'Multivitamins, protein powders, herbal supplements, and health boosters', '5', '6', '2026-05-27 02:29:48', '1'),
('97', 'Car Parts', 'Engine parts, brakes, filters, batteries, and lights', '6', '1', '2026-05-27 02:29:48', '1'),
('98', 'Motorcycle Parts', 'Spare parts, chains, brakes, tyres, and engine components for bikes', '6', '2', '2026-05-27 02:29:48', '1'),
('99', 'Car Accessories', 'Seat covers, steering wheels, car mats, air fresheners, and phone holders', '6', '3', '2026-05-27 02:29:48', '1'),
('100', 'Tyres & Wheels', 'Car and motorcycle tyres, rims, and wheel alignment services', '6', '4', '2026-05-27 02:29:48', '1'),
('101', 'Tools & Garage', 'Mechanics tools, jacks, diagnostic equipment, and garage storage', '6', '5', '2026-05-27 02:29:48', '1'),
('102', 'Baby Clothing', 'Onesies, rompers, pyjamas, and outfits for newborns and infants', '7', '1', '2026-05-27 02:29:48', '1'),
('103', 'Baby Gear', 'Strollers, car seats, baby carriers, walkers, and high chairs', '7', '2', '2026-05-27 02:29:48', '1'),
('104', 'Diapers & Wipes', 'Disposable and cloth diapers, baby wipes, and changing mats', '7', '3', '2026-05-27 02:29:48', '1'),
('105', 'Baby Food', 'Formula, purees, cereals, and snacks for babies and toddlers', '7', '4', '2026-05-27 02:29:48', '1'),
('106', 'Toys', 'Educational toys, dolls, action figures, puzzles, and outdoor play equipment', '7', '5', '2026-05-27 02:29:48', '1'),
('107', 'Exercise Equipment', 'Treadmills, weights, yoga mats, resistance bands, and fitness machines', '8', '1', '2026-05-27 02:29:48', '1');

DROP TABLE IF EXISTS `customer_notifications`;
CREATE TABLE `customer_notifications` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('order','delivery','promo','system') DEFAULT 'system',
  `reference_id` int(11) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`notification_id`),
  KEY `idx_cust_notif_customer` (`customer_id`),
  KEY `idx_cust_notif_type` (`type`),
  KEY `idx_cust_notif_read` (`is_read`),
  CONSTRAINT `fk_cust_notif_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `customer_notifications` VALUES
('46', '5', '📦 Order 58 -  Pending', 'Your order from \'Nyoni Collection\' (TSh 503,000) is now  Pending.', 'order', '58', '0', '2026-06-27 09:40:46'),
('47', '5', '🚚 Delivery 4 - Pending', 'Delivery for order 53 from \'Fashion shop\' is now Pending. Agent: Mohamed Ajemy', 'delivery', '4', '0', '2026-06-27 09:40:46'),
('48', '5', '📦 Order 58 -  Pending', 'Your order from \'Nyoni Collection\' (TSh 503,000) is now  Pending.', 'order', '58', '0', '2026-06-27 10:57:37'),
('49', '5', '🚚 Delivery 4 - Pending', 'Delivery for order 53 from \'Fashion shop\' is now Pending. Agent: Mohamed Ajemy', 'delivery', '4', '0', '2026-06-27 10:57:37'),
('50', '5', '📦 Order 60 -  Pending', 'Your order from \'Nyoni Collection\' (TSh 182,000) is now  Pending.', 'order', '60', '0', '2026-06-30 01:22:27'),
('51', '5', '📦 Order 59 -  Cancelled', 'Your order from \'Nyoni Collection\' (TSh 350,000) is now  Cancelled.', 'order', '59', '0', '2026-06-30 01:22:27'),
('52', '5', '📦 Order 58 -  Accepted', 'Your order from \'Nyoni Collection\' (TSh 503,000) is now  Accepted.', 'order', '58', '0', '2026-06-30 01:22:27'),
('53', '5', '🚚 Delivery 5 -  Assigned', 'Delivery for order 55 from \'Mquraysh Tech\' is now  Assigned. Agent: Mohamed Ajemy', 'delivery', '5', '0', '2026-06-30 01:22:27'),
('54', '5', '📦 Order 61 -  Pending', 'Your order from \'Nyoni Collection\' (TSh 182,000) is now  Pending.', 'order', '61', '0', '2026-06-30 03:03:22'),
('55', '5', '📦 Order 60 -  Pending', 'Your order from \'Nyoni Collection\' (TSh 182,000) is now  Pending.', 'order', '60', '0', '2026-06-30 03:03:22'),
('56', '5', '📦 Order 58 -  Accepted', 'Your order from \'Nyoni Collection\' (TSh 503,000) is now  Accepted.', 'order', '58', '0', '2026-06-30 03:03:22'),
('57', '5', '🚚 Delivery 5 -  Assigned', 'Delivery for order 55 from \'Mquraysh Tech\' is now  Assigned. Agent: Mohamed Ajemy', 'delivery', '5', '0', '2026-06-30 03:03:23'),
('58', '5', 'Delivery OTP Required', 'Please provide this OTP to confirm delivery: <strong>662754</strong>', '', NULL, '0', '2026-07-01 22:02:03');

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `saved_address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_preference` varchar(50) DEFAULT 'cash',
  `profile_image` varchar(255) DEFAULT NULL,
  `payment_pref` varchar(50) DEFAULT 'cash_on_delivery',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `uk_customers_user` (`user_id`),
  KEY `idx_customers_city` (`city`),
  CONSTRAINT `fk_customers_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `customers` VALUES
('5', '20', 'Twaha', 'Mohamed', 'Mabibo', 'Dar es Salaam', 'uploads/customers/customer_20_1780466370.webp', '2026-06-01 00:50:58', 'cash', 'assets/uploads/customers/customer_20_1781937709.webp', 'cash_on_delivery'),
('6', '23', 'FURAHA', 'SADOCK', 'chunya', 'mbeya', NULL, '2026-06-02 06:07:49', 'cash', NULL, 'cash_on_delivery'),
('8', '30', 'Pendael', 'Jumbe', 'Mabibo NIT', 'Dar es Salaam', NULL, '2026-06-10 16:16:12', 'cash', NULL, 'cash_on_delivery'),
('9', '32', 'samsung', 'ultra', 'Mbagala', 'Dar es Salaam', NULL, '2026-06-12 12:02:11', 'cash', NULL, 'cash_on_delivery'),
('10', '33', 'Abdulrazaq', 'Jafar', 'Mabibo', 'Dar es Salaam', NULL, '2026-06-12 13:02:07', 'cash', NULL, 'cash_on_delivery');

DROP TABLE IF EXISTS `deliveries`;
CREATE TABLE `deliveries` (
  `delivery_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `agent_id` int(11) DEFAULT NULL,
  `pickup_address` varchar(255) NOT NULL,
  `delivery_address` varchar(255) NOT NULL,
  `pickup_latitude` decimal(10,8) DEFAULT NULL,
  `pickup_longitude` decimal(11,8) DEFAULT NULL,
  `delivery_latitude` decimal(10,8) DEFAULT NULL,
  `delivery_longitude` decimal(11,8) DEFAULT NULL,
  `status` enum('pending','assigned','picked_up','in_transit','delivered','failed') DEFAULT 'pending',
  `assigned_at` timestamp NULL DEFAULT NULL,
  `picked_up_at` timestamp NULL DEFAULT NULL,
  `delivered_at` timestamp NULL DEFAULT NULL,
  `estimated_distance` decimal(10,2) DEFAULT NULL,
  `estimated_time` int(11) DEFAULT NULL,
  `delivery_fee` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rating` tinyint(1) DEFAULT NULL COMMENT '1-5 stars',
  `rating_comment` text DEFAULT NULL,
  `rated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`delivery_id`),
  UNIQUE KEY `uk_deliveries_order` (`order_id`),
  KEY `idx_deliveries_agent` (`agent_id`),
  KEY `idx_deliveries_status` (`status`),
  KEY `idx_deliveries_status_agent` (`status`,`agent_id`),
  KEY `idx_deliveries_created` (`created_at`),
  CONSTRAINT `fk_deliveries_agent` FOREIGN KEY (`agent_id`) REFERENCES `delivery_agents` (`agent_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_deliveries_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `deliveries` VALUES
('2', '54', '4', '', '', NULL, NULL, NULL, NULL, 'delivered', '2026-06-12 12:40:05', NULL, '2026-06-12 13:19:31', NULL, NULL, '5000.00', '2026-06-12 12:40:05', '2026-06-19 12:35:49', '3', 'goods', '2026-06-19 12:35:49'),
('3', '52', '4', '', '', NULL, NULL, NULL, NULL, 'in_transit', '2026-06-13 00:03:47', NULL, NULL, NULL, NULL, '5000.00', '2026-06-13 00:03:47', '2026-06-19 10:27:48', NULL, NULL, NULL),
('4', '53', '4', '', '', NULL, NULL, NULL, NULL, 'pending', '2026-06-19 11:18:14', NULL, NULL, NULL, NULL, '5000.00', '2026-06-19 11:18:14', '2026-06-21 00:41:54', NULL, NULL, NULL),
('5', '55', '4', '', '', NULL, NULL, NULL, NULL, 'assigned', '2026-06-27 12:44:02', NULL, NULL, NULL, NULL, '5000.00', '2026-06-27 12:44:02', '2026-06-27 12:44:02', NULL, NULL, NULL);

DROP TABLE IF EXISTS `delivery_agents`;
CREATE TABLE `delivery_agents` (
  `agent_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `vehicle_type` varchar(50) DEFAULT NULL,
  `vehicle_registration` varchar(50) DEFAULT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `license_number` varchar(50) DEFAULT NULL,
  `is_available` tinyint(1) DEFAULT 1,
  `current_latitude` decimal(10,8) DEFAULT NULL,
  `current_longitude` decimal(11,8) DEFAULT NULL,
  `total_deliveries` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `phone` varchar(20) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `vehicle_model` varchar(100) DEFAULT NULL,
  `vehicle_color` varchar(50) DEFAULT NULL,
  `insurance_expiry` date DEFAULT NULL,
  `avg_rating` decimal(3,2) DEFAULT 0.00,
  `total_ratings` int(11) DEFAULT 0,
  `rating` decimal(3,2) DEFAULT 0.00,
  `profile_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`agent_id`),
  UNIQUE KEY `uk_agents_user` (`user_id`),
  KEY `idx_agents_available` (`is_available`),
  KEY `idx_agents_status` (`status`),
  CONSTRAINT `fk_agents_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `delivery_agents` VALUES
('4', '25', 'Mohamed', 'Ajemy', 'motorcycle', 'T123ABC', '', 'DL123456', '1', NULL, NULL, '6', '2026-06-02 22:11:43', '0617666478', 'Kariakoo-Msimbazi', 'active', 'Boxer', 'Red', '2035-02-22', '3.00', '2', '3.00', 'assets/uploads/profiles/delivery_25_1782743335.jpg'),
('5', '26', 'Omary', 'Omary', 'Car', 'T123EBE', '2004110417102000120', 'DL123458', '1', NULL, NULL, '0', '2026-06-02 23:43:18', '0633424315', 'kigoma', 'active', '', '', '0000-00-00', '0.00', '0', NULL, NULL);

DROP TABLE IF EXISTS `delivery_history`;
CREATE TABLE `delivery_history` (
  `history_id` int(11) NOT NULL AUTO_INCREMENT,
  `delivery_id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`history_id`),
  KEY `idx_delivery_id` (`delivery_id`),
  CONSTRAINT `delivery_history_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`delivery_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `delivery_history` VALUES
('1', '4', 'in_transit', NULL, NULL, '', '', '2026-06-20 22:59:24'),
('2', '4', 'in_transit', NULL, NULL, '', '/UNK-System/assets/uploads/deliveries/delivery_4_1781985911.jpg', '2026-06-20 23:05:11'),
('3', '4', 'pending', NULL, NULL, '', NULL, '2026-06-20 23:11:29'),
('4', '4', 'assigned', NULL, NULL, '', NULL, '2026-06-20 23:26:36');

DROP TABLE IF EXISTS `delivery_otp_logs`;
CREATE TABLE `delivery_otp_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `delivery_agent_id` int(11) NOT NULL,
  `otp_code` varchar(10) NOT NULL,
  `generated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `status` enum('pending','verified','expired') NOT NULL DEFAULT 'pending',
  `attempts` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`log_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_delivery_agent_id` (`delivery_agent_id`),
  KEY `idx_otp_code` (`otp_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `delivery_rates`;
CREATE TABLE `delivery_rates` (
  `rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `min_distance` decimal(10,2) NOT NULL,
  `max_distance` decimal(10,2) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`rate_id`),
  KEY `idx_rates_distance` (`min_distance`,`max_distance`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `delivery_rates` VALUES
('1', '0.00', '1.00', '2500.00', 'Within 2km', '2026-06-07 08:30:16', '1'),
('2', '2.00', '3.00', '3500.00', '2-3km', '2026-06-07 08:30:16', '1'),
('3', '5.00', '8.00', '7000.00', '5-8km', '2026-06-07 08:30:16', '1'),
('4', '8.00', '11.00', '10000.00', '8-11km', '2026-06-07 08:30:16', '1'),
('6', '11.00', '14.00', '20000.00', '', '2026-06-29 13:13:12', '1');

DROP TABLE IF EXISTS `delivery_ratings`;
CREATE TABLE `delivery_ratings` (
  `rating_id` int(11) NOT NULL AUTO_INCREMENT,
  `delivery_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `rating` tinyint(1) NOT NULL CHECK (`rating` between 1 and 5),
  `comment` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`rating_id`),
  KEY `idx_delivery_id` (`delivery_id`),
  KEY `idx_agent_id` (`agent_id`),
  KEY `idx_customer_id` (`customer_id`),
  CONSTRAINT `delivery_ratings_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`delivery_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `delivery_ratings` VALUES
('1', '2', '5', '4', '54', '3', 'goods', '2026-06-19 12:35:49');

DROP TABLE IF EXISTS `delivery_tracking`;
CREATE TABLE `delivery_tracking` (
  `tracking_id` int(11) NOT NULL AUTO_INCREMENT,
  `delivery_id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `location_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`tracking_id`),
  KEY `idx_delivery_id` (`delivery_id`),
  CONSTRAINT `delivery_tracking_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`delivery_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `delivery_tracking` VALUES
('1', '3', 'picked_up', '', '2026-06-13 00:19:40');

DROP TABLE IF EXISTS `delivery_updates`;
CREATE TABLE `delivery_updates` (
  `update_id` int(11) NOT NULL AUTO_INCREMENT,
  `delivery_id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`update_id`),
  KEY `idx_updates_delivery` (`delivery_id`),
  KEY `idx_updates_time` (`update_time`),
  CONSTRAINT `fk_updates_delivery` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`delivery_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `delivery_updates` VALUES
('4', '2', 'picked_up', NULL, NULL, NULL, 'Status updated by agent to picked up', '2026-06-12 12:43:15'),
('5', '2', 'in_transit', NULL, NULL, NULL, 'Status updated by agent to in transit', '2026-06-12 12:43:34'),
('6', '2', 'delivered', NULL, NULL, NULL, 'Status updated by agent to delivered', '2026-06-12 13:19:31');

DROP TABLE IF EXISTS `earnings`;
CREATE TABLE `earnings` (
  `earning_id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `delivery_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('pending','paid') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `paid_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`earning_id`),
  KEY `idx_agent_id` (`agent_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_delivery_id` (`delivery_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `earnings_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `delivery_agents` (`agent_id`) ON DELETE CASCADE,
  CONSTRAINT `earnings_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  CONSTRAINT `earnings_ibfk_3` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`delivery_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `email_logs`;
CREATE TABLE `email_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `template_key` varchar(100) DEFAULT NULL,
  `recipient` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `status` enum('sent','failed','pending') DEFAULT 'sent',
  `error_message` text DEFAULT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`),
  KEY `idx_recipient` (`recipient`),
  KEY `idx_status` (`status`),
  KEY `idx_sent_at` (`sent_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `email_templates`;
CREATE TABLE `email_templates` (
  `template_id` int(11) NOT NULL AUTO_INCREMENT,
  `template_key` varchar(100) NOT NULL,
  `template_name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `variables` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`template_id`),
  UNIQUE KEY `template_key` (`template_key`),
  KEY `idx_template_key` (`template_key`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `email_templates` VALUES
('1', 'order_confirmation', 'Order Confirmation', 'Order Confirmation {order_id}', 'Dear {customer_name},\r\n\r\nThank you for your order {order_id}.\r\n\r\nOrder Details:\r\n{order_details}\r\n\r\nTotal: {total_amount}\r\n\r\nWe will notify you when your order is shipped.\r\n\r\nThank you for shopping with us!', 'Sent when a customer places an order', 'customer_name, order_id, order_details, total_amount', '1', '2026-06-21 20:33:24', '2026-06-27 12:53:57'),
('2', 'order_shipped', 'Order Shipped', 'Your order {order_id} has been shipped', 'Dear {customer_name},\r\n\r\nYour order {order_id} has been shipped!\r\n\r\nDelivery Agent: {agent_name}\r\nTracking: {tracking_link}\r\n\r\nEstimated Delivery: {estimated_delivery}', 'Sent when an order is shipped', 'customer_name, order_id, agent_name, tracking_link, estimated_delivery', '1', '2026-06-21 20:33:24', '2026-06-27 12:55:01'),
('3', 'order_delivered', 'Order Delivered', 'Your order {order_id} has been delivered', 'Dear {customer_name},\r\n\r\nYour order {order_id} has been delivered successfully.\r\n\r\nWe hope you enjoy your purchase!\r\n\r\nPlease leave a review: {review_link}', 'Sent when an order is delivered', 'customer_name, order_id, review_link', '1', '2026-06-21 20:33:24', '2026-06-27 12:55:01'),
('4', 'password_reset', 'Password Reset', 'Reset your password', 'Dear {user_name},\r\n\r\nYou requested to reset your password.\r\n\r\nClick the link below to reset your password:\r\n{reset_link}\r\n\r\nThis link will expire in 24 hours.\r\n\r\nIf you did not request this, please ignore this email.', 'Sent when a user requests password reset', 'user_name, reset_link', '1', '2026-06-21 20:33:24', '2026-06-21 20:33:54'),
('5', 'welcome_email', 'Welcome Email', 'Welcome to UNK System!', 'Welcome to UNK System!\r\n\r\nDear {user_name},\r\n\r\nThank you for registering with us.\r\n\r\nYou can now start shopping and exploring our marketplace.\r\n\r\nVisit: {login_link}', 'Sent when a new user registers', 'user_name, login_link', '1', '2026-06-21 20:33:24', '2026-06-21 20:33:54'),
('6', 'business_approval', 'Business Approval', 'Your business has been approved!', 'Dear {business_name},\r\n\r\nYour business has been approved!\r\n\r\nYou can now start listing products and selling on UNK System.\r\n\r\nLogin to your dashboard: {dashboard_link}', 'Sent when a business is approved', 'business_name, dashboard_link', '1', '2026-06-21 20:33:24', '2026-06-21 20:33:54'),
('7', 'delivery_assigned', 'Delivery Assigned', 'New delivery assigned to you', 'Dear {agent_name},\r\n\r\nYou have been assigned a new delivery.\r\n\r\nOrder ID: {order_id}\r\nPickup: {pickup_address}\r\nDelivery: {delivery_address}\r\n\r\nPlease login to accept this delivery.', 'Sent when a delivery is assigned to an agent', 'agent_name, order_id, pickup_address, delivery_address', '1', '2026-06-21 20:33:24', '2026-06-21 20:33:54');

DROP TABLE IF EXISTS `login_history`;
CREATE TABLE `login_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `login_time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_login_time` (`login_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `notif_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `is_read` tinyint(4) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`notif_id`),
  KEY `idx_notifications_user` (`user_id`),
  KEY `idx_notifications_order` (`order_id`),
  KEY `idx_notifications_read` (`is_read`),
  KEY `idx_notifications_created` (`created_at`),
  CONSTRAINT `fk_notifications_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `notifications` VALUES
('37', '20', '48', 'Order #48 Updated', 'Order status changed from Pending to Accepted. ', '0', '2026-06-11 18:51:04'),
('38', '20', '48', 'Order #48 Updated', 'Order status changed from Accepted to Confirmed. ', '0', '2026-06-11 21:58:57'),
('39', '20', '48', 'Order #48 Updated', 'Order status changed from Confirmed to Preparing. ', '0', '2026-06-11 21:59:17'),
('40', '20', '48', 'Order 48 Updated', 'Payment status changed from Pending to Paid.', '0', '2026-06-11 22:02:37'),
('41', '20', '48', 'Order 48 Updated', 'Payment status changed from Paid to Pending.', '0', '2026-06-11 22:04:21'),
('42', '20', '48', 'Order 48 Updated', 'Payment status changed from Pending to Paid.', '0', '2026-06-11 22:34:56'),
('43', '20', '48', 'Order 48 Updated', 'Order status changed from Confirmed to Preparing. ', '0', '2026-06-12 12:10:57'),
('44', '20', '48', 'Order 48 Updated', 'Order status changed from Preparing to Ready. ', '0', '2026-06-12 12:11:10'),
('45', '20', '54', 'Order 54 Updated', 'Order status changed from Pending to Accepted. ', '0', '2026-06-12 12:36:44'),
('46', '20', '54', 'Order 54 Updated', 'Order status changed from Accepted to Confirmed. ', '0', '2026-06-12 12:36:54'),
('47', '20', '54', 'Order 54 Updated', 'Order status changed from Confirmed to Preparing. ', '0', '2026-06-12 12:37:11'),
('48', '20', '54', 'Order 54 Updated', 'Order status changed from Confirmed to Preparing. ', '0', '2026-06-12 12:42:17'),
('49', '20', '54', 'Order 54 Updated', 'Order status changed from Preparing to Ready. ', '0', '2026-06-12 12:42:29'),
('50', '20', '53', 'Order 53 Updated', 'Order status changed from Pending to Accepted. ', '0', '2026-06-13 00:01:36'),
('51', '20', '53', 'Order 53 Updated', 'Order status changed from Accepted to Confirmed. ', '0', '2026-06-13 00:01:44'),
('52', '20', '53', 'Order 53 Updated', 'Order status changed from Confirmed to Preparing. ', '0', '2026-06-13 00:01:51'),
('53', '20', '52', 'Order 52 Updated', 'Order status changed from Pending to Accepted. ', '0', '2026-06-13 00:02:06'),
('54', '20', '52', 'Order 52 Updated', 'Order status changed from Accepted to Confirmed. ', '0', '2026-06-13 00:02:15'),
('55', '20', '52', 'Order 52 Updated', 'Order status changed from Confirmed to Preparing. ', '0', '2026-06-13 00:02:22'),
('56', '20', '55', 'Order 55 Updated', 'Order status changed from Pending to Accepted. ', '0', '2026-06-19 15:44:08'),
('57', '20', '55', 'Order 55 Updated', 'Order status changed from Accepted to Confirmed. ', '0', '2026-06-19 15:44:22'),
('58', '20', '55', 'Order 55 Updated', 'Order status changed from Confirmed to Preparing. ', '0', '2026-06-19 15:44:40'),
('59', '20', '58', 'Order 58 Updated', 'Order status changed from Pending to Accepted. ', '0', '2026-06-29 14:11:27');

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `order_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `idx_order_items_order` (`order_id`),
  KEY `idx_order_items_product` (`product_id`),
  CONSTRAINT `fk_order_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_order_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `order_items` VALUES
('52', '48', '49', '1', '500000.00', '500000.00'),
('53', '48', '47', '1', '450000.00', '450000.00'),
('57', '52', '53', '1', '45000.00', '45000.00'),
('58', '53', '57', '1', '35000.00', '35000.00'),
('59', '54', '48', '1', '500000.00', '500000.00'),
('60', '54', '46', '1', '500000.00', '500000.00'),
('61', '55', '41', '1', '270000.00', '270000.00'),
('62', '56', '58', '1', '25000.00', '25000.00'),
('64', '58', '44', '1', '500000.00', '500000.00');

DROP TABLE IF EXISTS `order_status_history`;
CREATE TABLE `order_status_history` (
  `history_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `old_status` varchar(50) DEFAULT NULL,
  `new_status` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `old_payment` varchar(20) DEFAULT NULL,
  `new_payment` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`history_id`),
  KEY `idx_osh_order` (`order_id`),
  KEY `idx_osh_created_by` (`created_by`),
  KEY `idx_osh_created` (`created_at`),
  CONSTRAINT `fk_osh_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_osh_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `order_status_history` VALUES
('45', '48', 'pending', 'accepted', '', '19', '2026-06-11 18:51:04', 'pending', 'pending'),
('46', '48', 'accepted', 'confirmed', '', '19', '2026-06-11 21:58:57', 'pending', 'pending'),
('47', '48', 'confirmed', 'preparing', '', '19', '2026-06-11 21:59:17', 'pending', 'pending'),
('48', '48', 'preparing', 'preparing', '', '19', '2026-06-11 22:02:37', 'pending', 'paid'),
('49', '48', 'preparing', 'preparing', '', '19', '2026-06-11 22:04:21', 'paid', 'pending'),
('50', '48', 'preparing', 'preparing', '', '19', '2026-06-11 22:34:56', 'pending', 'paid'),
('51', '48', 'confirmed', 'preparing', '', '19', '2026-06-12 12:10:57', 'paid', 'paid'),
('52', '48', 'preparing', 'ready', '', '19', '2026-06-12 12:11:10', 'paid', 'paid'),
('53', '54', 'pending', 'accepted', '', '19', '2026-06-12 12:36:43', 'pending', 'pending'),
('54', '54', 'accepted', 'confirmed', '', '19', '2026-06-12 12:36:54', 'pending', 'pending'),
('55', '54', 'confirmed', 'preparing', '', '19', '2026-06-12 12:37:11', 'pending', 'pending'),
('56', '54', 'confirmed', 'preparing', '', '19', '2026-06-12 12:42:17', 'pending', 'pending'),
('57', '54', 'preparing', 'ready', '', '19', '2026-06-12 12:42:29', 'pending', 'pending'),
('58', '53', 'pending', 'accepted', '', '31', '2026-06-13 00:01:36', 'pending', 'pending'),
('59', '53', 'accepted', 'confirmed', '', '31', '2026-06-13 00:01:44', 'pending', 'pending'),
('60', '53', 'confirmed', 'preparing', '', '31', '2026-06-13 00:01:51', 'pending', 'pending'),
('61', '52', 'pending', 'accepted', '', '31', '2026-06-13 00:02:06', 'pending', 'pending'),
('62', '52', 'accepted', 'confirmed', '', '31', '2026-06-13 00:02:15', 'pending', 'pending'),
('63', '52', 'confirmed', 'preparing', '', '31', '2026-06-13 00:02:22', 'pending', 'pending'),
('64', '55', 'pending', 'accepted', 'accept', '28', '2026-06-19 15:44:08', 'pending', 'pending'),
('65', '55', 'accepted', 'confirmed', '', '28', '2026-06-19 15:44:22', 'pending', 'pending'),
('66', '55', 'confirmed', 'preparing', '', '28', '2026-06-19 15:44:38', 'pending', 'pending'),
('67', '58', 'pending', 'accepted', '', '19', '2026-06-29 14:11:27', 'pending', 'pending');

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `total_amount` decimal(10,2) NOT NULL,
  `delivery_fee` decimal(10,2) DEFAULT 0.00,
  `agent_id` int(11) DEFAULT NULL,
  `grand_total` decimal(10,2) NOT NULL,
  `status` enum('pending','accepted','confirmed','preparing','ready','picked_up','in_transit','delivered','cancelled') DEFAULT 'pending',
  `delivery_otp` varchar(10) DEFAULT NULL,
  `delivery_otp_expires` timestamp NULL DEFAULT NULL,
  `delivery_otp_verified` tinyint(1) NOT NULL DEFAULT 0,
  `delivery_completed_at` timestamp NULL DEFAULT NULL,
  `payment_method` enum('cash','mobile_money','card') DEFAULT 'cash',
  `payment_status` enum('pending','paid') DEFAULT 'pending',
  `delivery_address` text NOT NULL,
  `contact_phone` varchar(20) NOT NULL,
  `special_instructions` text DEFAULT NULL,
  `estimated_delivery_time` datetime DEFAULT NULL,
  `delivery_latitude` decimal(10,8) DEFAULT NULL,
  `delivery_longitude` decimal(11,8) DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  KEY `idx_orders_customer` (`customer_id`),
  KEY `idx_orders_business` (`business_id`),
  KEY `idx_orders_status` (`status`),
  KEY `idx_orders_date` (`order_date`),
  KEY `idx_orders_agent` (`agent_id`),
  KEY `idx_orders_payment_status` (`payment_status`),
  KEY `idx_orders_customer_status` (`customer_id`,`status`),
  KEY `idx_orders_business_status` (`business_id`,`status`),
  KEY `idx_orders_date_status` (`order_date`,`status`),
  KEY `idx_orders_grand_total` (`grand_total`),
  CONSTRAINT `fk_orders_agent` FOREIGN KEY (`agent_id`) REFERENCES `delivery_agents` (`agent_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_orders_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`business_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_orders_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `orders` VALUES
('48', '5', '7', '2026-06-10 11:35:37', '950000.00', '4000.00', '4', '954000.00', 'delivered', NULL, NULL, '0', NULL, 'cash', 'paid', 'mabibo', '', '[Payment: Cash]', NULL, NULL, NULL),
('52', '5', '11', '2026-06-12 12:34:26', '45000.00', '5000.00', '4', '50000.00', 'confirmed', NULL, NULL, '0', NULL, 'cash', 'pending', 'Ubungo-Maziwa', '', '[Payment: Cash]', NULL, NULL, NULL),
('53', '5', '11', '2026-06-12 12:35:00', '35000.00', '5000.00', '4', '40000.00', 'confirmed', NULL, NULL, '0', NULL, 'cash', 'pending', 'Ubungo-Maziwa', '', '[Payment: Cash]', NULL, NULL, NULL),
('54', '5', '7', '2026-06-12 12:35:32', '1000000.00', '5000.00', '4', '1005000.00', 'delivered', NULL, NULL, '0', NULL, 'cash', 'pending', 'Ubungo-Maziwa', '', '[Payment: Cash]', NULL, NULL, NULL),
('55', '5', '10', '2026-06-19 15:37:49', '270000.00', '5000.00', '4', '275000.00', '', '662754', '2026-07-01 21:17:03', '0', NULL, 'cash', 'pending', 'Ubungo-Maziwa', '', '[Payment: Cash]', NULL, NULL, NULL),
('56', '5', '11', '2026-06-19 15:37:50', '25000.00', '5000.00', NULL, '30000.00', 'pending', NULL, NULL, '0', NULL, 'cash', 'pending', 'Ubungo-Maziwa', '', '[Payment: Cash]', NULL, NULL, NULL),
('58', '5', '7', '2026-06-26 19:28:01', '500000.00', '3000.00', NULL, '503000.00', 'accepted', NULL, NULL, '0', NULL, 'cash', 'pending', 'Ubungo-Maziwa', '', '[Payment: Cash]', NULL, NULL, NULL);

DROP TABLE IF EXISTS `otp_verifications`;
CREATE TABLE `otp_verifications` (
  `otp_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `otp_code` varchar(10) NOT NULL,
  `purpose` enum('login','admin_login','registration','2fa','order_verification','payment_verification','business_verification','email_change','phone_verification','delete_account','delivery_verification','customer_password_reset','business_password_reset','delivery_password_reset') NOT NULL,
  `reference_id` int(11) DEFAULT NULL COMMENT 'Order ID, Business ID, etc.',
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_used` tinyint(1) NOT NULL DEFAULT 0,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`otp_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_phone_number` (`phone_number`),
  KEY `idx_email` (`email`),
  KEY `idx_otp_code` (`otp_code`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_is_used` (`is_used`),
  KEY `idx_purpose` (`purpose`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `otp_verifications` VALUES
('13', NULL, NULL, 'mohamed@gmail.com', '096562', '', NULL, '2026-07-01 12:53:48', '0', '0', '2026-07-01 13:43:48', '2026-07-01 13:43:48'),
('35', NULL, NULL, 'albinokh425@gmail.com', '197927', '', NULL, '2026-07-01 14:33:54', '1', '0', '2026-07-01 15:23:54', '2026-07-01 15:24:13'),
('36', NULL, NULL, 'albinokh425@gmail.com', '274782', '', NULL, '2026-07-01 14:47:15', '0', '0', '2026-07-01 15:37:15', '2026-07-01 15:37:15'),
('37', NULL, NULL, 'albinokh425@gmail.com', '395611', '', NULL, '2026-07-01 14:48:05', '0', '0', '2026-07-01 15:38:05', '2026-07-01 15:38:05'),
('40', NULL, NULL, 'mwaminnyoni@gmail.com', '502695', '', NULL, '2026-07-01 15:22:18', '0', '0', '2026-07-01 16:12:18', '2026-07-01 16:12:18'),
('46', NULL, NULL, 'admin@unksystem.com', '500493', 'admin_login', NULL, '2026-07-01 15:58:20', '1', '1', '2026-07-01 16:48:20', '2026-07-01 16:51:09'),
('48', NULL, NULL, 'admin@unksystem.com', '657439', 'admin_login', NULL, '2026-07-01 16:01:23', '1', '4', '2026-07-01 16:51:23', '2026-07-01 17:05:58'),
('50', NULL, NULL, 'admin@unksystem.com', '299338', 'login', NULL, '2026-07-01 16:15:19', '0', '0', '2026-07-01 17:05:19', '2026-07-01 17:05:19'),
('51', NULL, NULL, 'admin@unksystem.com', '216311', 'admin_login', NULL, '2026-07-01 16:20:05', '1', '0', '2026-07-01 17:10:05', '2026-07-01 17:10:31'),
('55', NULL, NULL, 'twahakh425@gmail.com', '477100', 'login', NULL, '2026-07-01 16:29:50', '0', '0', '2026-07-01 17:19:50', '2026-07-01 17:19:50'),
('61', NULL, NULL, 'mwaminnyoni@gmail.com', '283125', 'login', NULL, '2026-07-01 16:54:22', '1', '0', '2026-07-01 17:44:22', '2026-07-01 17:45:12'),
('65', NULL, NULL, 'albinokh425@gmail.com', '184991', 'customer_password_reset', NULL, '2026-07-01 17:23:02', '1', '0', '2026-07-01 18:13:02', '2026-07-01 18:13:48'),
('66', NULL, NULL, 'mwaminnyoni@gmail.com', '443081', 'business_password_reset', NULL, '2026-07-01 17:32:52', '1', '0', '2026-07-01 18:22:52', '2026-07-01 18:28:06'),
('67', NULL, NULL, 'mohamed@gmail.com', '876204', 'delivery_password_reset', NULL, '2026-07-01 17:41:01', '1', '0', '2026-07-01 18:31:01', '2026-07-01 18:33:56'),
('68', NULL, NULL, 'albinokh425@gmail.com', '113090', 'login', NULL, '2026-07-01 18:10:32', '1', '0', '2026-07-01 19:00:32', '2026-07-01 19:01:05'),
('74', NULL, NULL, 'albinokh425@gmail.com', '937524', 'order_verification', '66', '2026-07-01 19:39:06', '1', '0', '2026-07-01 20:29:06', '2026-07-01 20:29:37'),
('75', NULL, NULL, 'mohamed@gmail.com', '836033', 'login', NULL, '2026-07-01 20:21:43', '1', '0', '2026-07-01 21:11:43', '2026-07-01 21:12:16'),
('76', NULL, NULL, 'admin@unksystem.com', '969516', 'admin_login', NULL, '2026-07-02 09:36:14', '1', '0', '2026-07-02 10:26:14', '2026-07-02 10:26:51'),
('77', NULL, NULL, 'admin@unksystem.com', '703051', 'admin_login', NULL, '2026-07-02 09:36:28', '0', '0', '2026-07-02 10:26:28', '2026-07-02 10:26:28'),
('78', NULL, NULL, 'admin@unksystem.com', '591926', 'admin_login', NULL, '2026-07-02 09:37:20', '1', '0', '2026-07-02 10:27:20', '2026-07-02 10:27:56');

DROP TABLE IF EXISTS `price_alerts`;
CREATE TABLE `price_alerts` (
  `alert_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `desired_price` decimal(10,2) NOT NULL,
  `status` enum('active','triggered','cancelled') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`alert_id`),
  KEY `idx_alerts_customer` (`customer_id`),
  KEY `idx_alerts_product` (`product_id`),
  KEY `idx_alerts_status` (`status`),
  CONSTRAINT `fk_alerts_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_alerts_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `price_alerts` VALUES
('10', '5', '49', '400000.00', 'cancelled', '2026-06-09 18:38:02'),
('11', '5', '44', '400000.00', 'cancelled', '2026-06-09 18:44:57'),
('12', '5', '41', '216000.00', 'cancelled', '2026-06-09 18:53:34'),
('13', '5', '49', '400000.00', 'active', '2026-06-09 18:59:36'),
('14', '5', '37', '224000.00', 'active', '2026-06-09 19:09:51'),
('15', '5', '36', '224000.00', 'active', '2026-06-09 19:12:01');

DROP TABLE IF EXISTS `price_history`;
CREATE TABLE `price_history` (
  `history_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`history_id`),
  KEY `idx_price_history_product` (`product_id`,`recorded_at`),
  CONSTRAINT `fk_price_history_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `product_images`;
CREATE TABLE `product_images` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `is_primary` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`image_id`),
  KEY `idx_images_product` (`product_id`),
  KEY `idx_images_primary` (`is_primary`),
  CONSTRAINT `fk_images_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity_in_stock` int(11) DEFAULT 0,
  `unit` varchar(20) DEFAULT NULL,
  `min_order` int(11) DEFAULT 1,
  `image_url` varchar(255) DEFAULT NULL,
  `is_available` tinyint(1) DEFAULT 1,
  `views` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  `style_category` varchar(50) DEFAULT 'General',
  `discount_percent` int(11) DEFAULT 0,
  `discount_start_date` date DEFAULT NULL,
  `discount_end_date` date DEFAULT NULL,
  `is_on_sale` tinyint(1) DEFAULT 0,
  `image_hash` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`product_id`),
  KEY `idx_products_business` (`business_id`),
  KEY `idx_products_category` (`category_id`),
  KEY `idx_products_price` (`price`),
  KEY `idx_products_name` (`name`(100)),
  KEY `idx_products_available` (`is_available`),
  KEY `idx_products_business_available` (`business_id`,`is_available`),
  KEY `idx_products_category_price` (`category_id`,`price`),
  KEY `idx_products_price_range` (`price`),
  KEY `idx_products_name_search` (`name`(50)),
  KEY `idx_image_hash` (`image_hash`),
  CONSTRAINT `fk_products_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`business_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `products` VALUES
('26', '10', '67', 'Samsung S10 plus', 'Samsung s10 plus RAM 12 GB 256', '370000.00', '22', 'piece', '1', 'assets/uploads/products/1780413814_6a1ef576b24f2.webp', '1', '12', '2026-06-03 04:23:34', '2026-06-08 01:16:25', NULL, 'General', '0', NULL, NULL, '0', NULL),
('36', '10', '67', 'samsung s10 pro', '', '280000.00', '21', 'piece', '1', 'assets/uploads/products/1780546795_6a20fceb50ac4.webp', '1', '10', '2026-06-04 07:19:55', '2026-06-30 03:07:17', NULL, 'General', '0', NULL, NULL, '0', NULL),
('37', '10', '67', 'samsung s10 pro', '', '280000.00', '29', 'piece', '1', 'assets/uploads/products/1780548688_6a2104504d910.webp', '1', '10', '2026-06-04 07:51:28', '2026-06-11 21:11:52', NULL, 'General', '0', NULL, NULL, '0', NULL),
('38', '10', '67', 'samsung s21 ultra', '', '750000.00', '21', 'piece', '1', 'assets/uploads/products/1780548759_6a2104974ab0c.webp', '1', '4', '2026-06-04 07:52:39', '2026-06-08 01:26:41', NULL, 'General', '0', NULL, NULL, '0', NULL),
('39', '10', '67', 'samsung note10 plus', '', '500000.00', '13', 'piece', '1', 'assets/uploads/products/1780548841_6a2104e90866f.webp', '1', '4', '2026-06-04 07:54:01', '2026-06-10 19:48:17', NULL, 'General', '0', NULL, NULL, '0', NULL),
('40', '10', '67', 'samsung s22 ultra', '', '870000.00', '13', 'piece', '1', 'assets/uploads/products/1780548932_6a2105449b491.webp', '1', '6', '2026-06-04 07:55:32', '2026-06-11 19:54:01', NULL, 'General', '0', NULL, NULL, '0', NULL),
('41', '10', '67', 'samsung s10 pro', '', '270000.00', '12', 'piece', '1', 'assets/uploads/products/1780548997_6a210585b2c5b.webp', '1', '11', '2026-06-04 07:56:37', '2026-06-27 18:08:09', NULL, 'General', '0', NULL, NULL, '0', NULL),
('42', '10', '67', 'samsung s10 pro', 'used RAM 8 GB 128, no finger plint', '260000.00', '21', 'piece', '1', 'assets/uploads/products/1780549107_6a2105f38e310.webp', '1', '22', '2026-06-04 07:58:27', '2026-06-19 15:36:16', NULL, 'General', '0', NULL, NULL, '0', NULL),
('43', '7', '82', 'curtains', 'Darkblue and White', '500000.00', '21', 'piece', '1', 'assets/uploads/products/1780549697_6a21084173a28.jpeg', '1', '18', '2026-06-04 08:08:17', '2026-06-11 15:22:29', NULL, 'General', '0', NULL, NULL, '0', NULL),
('44', '7', '82', 'curtains', 'Curtains For home, office and school', '500000.00', '18', 'piece', '1', 'assets/uploads/products/1780549793_6a2108a1422fd.jpeg', '1', '11', '2026-06-04 08:09:53', '2026-06-30 02:30:55', NULL, 'General', '0', NULL, NULL, '0', NULL),
('45', '7', '82', 'curtains', 'Curtains For home, office and school', '350000.00', '12', 'piece', '1', 'assets/uploads/products/1780549867_6a2108eb9b7b0.jpeg', '1', '8', '2026-06-04 08:10:31', '2026-06-10 19:03:44', NULL, 'General', '0', NULL, NULL, '0', NULL),
('46', '7', '82', 'curtains', 'Curtains For home, office and school', '500000.00', '11', 'piece', '1', 'assets/uploads/products/1780549916_6a21091c8bfd1.jpeg', '1', '15', '2026-06-04 08:11:56', '2026-06-12 12:35:32', NULL, 'General', '0', NULL, NULL, '0', NULL),
('47', '7', '82', 'curtains', '0', '450000.00', '11', 'piece', '1', 'assets/uploads/products/1780550005_6a2109754664d.jpeg', '1', '20', '2026-06-04 08:13:25', '2026-06-26 19:36:51', NULL, 'General', '0', NULL, NULL, '0', NULL),
('48', '7', '82', 'curtains', 'Curtains for home, office and others best for price', '500000.00', '12', 'piece', '1', 'assets/uploads/products/1780609524_6a21f1f4bec24.jpeg', '1', '62', '2026-06-05 00:45:24', '2026-06-30 03:26:24', NULL, 'General', '0', NULL, NULL, '0', NULL),
('49', '7', '82', 'curtains', 'white and black curtains', '500000.00', '18', 'piece', '1', 'assets/uploads/products/1780609600_6a21f2402c79b.jpeg', '1', '44', '2026-06-05 00:46:40', '2026-06-14 08:55:46', NULL, 'General', '0', NULL, NULL, '0', NULL),
('51', '10', '68', 'Hp pc', '', '370000.00', '13', 'piece', '1', 'assets/uploads/products/1781179469_6a2aa44dac528.jpg', '1', '6', '2026-06-11 15:04:29', '2026-06-27 13:22:48', NULL, 'General', '0', NULL, NULL, '0', NULL),
('52', '11', '78', 'Watch', 'Gold watch', '35000.00', '16', 'piece', '1', 'assets/uploads/products/1781220872_6a2b46085fcc8.webp', '1', '1', '2026-06-12 02:34:32', '2026-06-12 02:57:53', NULL, 'General', '0', NULL, NULL, '0', NULL),
('53', '11', '78', 'Tissot-Chrono-XL-1-1024x667 watch', 'Tissot-Chrono-XL-1-1024x667 watch', '45000.00', '11', 'piece', '1', 'assets/uploads/products/1781220975_6a2b466fb9ce7.jpg', '1', '3', '2026-06-12 02:36:15', '2026-06-30 03:07:24', NULL, 'General', '0', NULL, NULL, '0', NULL),
('54', '11', '78', 'pexels-fernando-arcos-watch', 'pexels-fernando-arcos-190819-scaled watch for Women & Men', '35000.00', '13', 'piece', '1', 'assets/uploads/products/1781221136_6a2b4710d19be.jpg', '1', '8', '2026-06-12 02:38:56', '2026-07-01 20:29:05', NULL, 'General', '0', NULL, NULL, '0', NULL),
('55', '11', '78', 'pexels-fernando-arcos-watch', 'pexels-fernando-arcos-190819-scaled-e1602768420525', '35000.00', '14', 'piece', '1', 'assets/uploads/products/1781221233_6a2b4771e9b97.jpg', '1', '2', '2026-06-12 02:40:33', '2026-06-27 12:47:01', NULL, 'General', '0', NULL, NULL, '0', NULL),
('56', '11', '78', 'OIP women watch', 'OIP women watch', '50000.00', '14', 'piece', '1', 'assets/uploads/products/1781221299_6a2b47b3922ae.webp', '1', '6', '2026-06-12 02:41:39', '2026-06-27 09:38:51', NULL, 'General', '0', NULL, NULL, '0', NULL),
('57', '11', '78', 'Tissot-Chrono-XL-1-1024x667 watch', 'Tissot-Chrono-XL-1-1024x667 watch', '35000.00', '17', 'piece', '1', 'assets/uploads/products/1781221365_6a2b47f58ca02.jpg', '1', '15', '2026-06-12 02:42:45', '2026-06-27 14:50:50', NULL, 'General', '0', NULL, NULL, '0', NULL),
('58', '11', '78', 'pin de R. H. en Audemars Piguet watch', 'pin de R. H. en Audemars Piguet for women and Men', '25000.00', '9', 'piece', '1', 'assets/uploads/products/1781221479_6a2b48679cf97.webp', '1', '13', '2026-06-12 02:44:39', '2026-07-01 19:31:03', NULL, 'General', '0', NULL, NULL, '0', NULL),
('59', '7', '79', 'Dressing Table', 'usafiri ni bure kwa wakazi wa Dar es Salaam', '235000.00', '11', 'piece', '1', 'assets/uploads/products/1782625615_6a40b54fdbc32.jpg', '1', '8', '2026-06-28 08:46:55', '2026-06-28 22:19:24', NULL, 'General', '0', NULL, NULL, '0', NULL),
('60', '7', '79', 'Dressings Table', 'Dressings Table', '200000.00', '16', 'piece', '1', 'assets/uploads/products/1782625807_6a40b60f0c98f.jpg', '1', '5', '2026-06-28 08:50:07', '2026-07-01 22:15:53', NULL, 'General', '0', NULL, NULL, '0', NULL),
('61', '7', '79', 'Dressings Table', '', '285000.00', '9', 'piece', '1', 'assets/uploads/products/1782626150_6a40b766488b1.jpg', '1', '4', '2026-06-28 08:55:50', '2026-07-01 21:10:44', NULL, 'General', '0', NULL, NULL, '0', NULL),
('63', '7', '79', 'Dressings Table', '', '175000.00', '11', 'piece', '1', 'assets/uploads/products/1782626509_6a40b8cd5140d.jpg', '1', '2', '2026-06-28 09:01:49', '2026-06-30 02:41:34', NULL, 'General', '0', NULL, NULL, '0', NULL),
('64', '7', '79', 'Dressings Table', '', '175000.00', '10', 'piece', '1', 'assets/uploads/products/1782626558_6a40b8fe94870.jpg', '1', '2', '2026-06-28 09:02:38', '2026-06-30 01:21:52', NULL, 'General', '0', NULL, NULL, '0', NULL),
('65', '7', '79', 'Dressings Table', '', '175000.00', '6', 'piece', '1', 'assets/uploads/products/1782626615_6a40b937e2088.jpg', '1', '10', '2026-06-28 09:03:35', '2026-07-01 19:59:38', NULL, 'General', '0', NULL, NULL, '0', NULL);

DROP TABLE IF EXISTS `return_requests`;
CREATE TABLE `return_requests` (
  `return_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `ticket_id` int(11) DEFAULT NULL,
  `return_number` varchar(50) NOT NULL,
  `reason` text NOT NULL,
  `status` enum('pending','approved','rejected','completed') DEFAULT 'pending',
  `refund_amount` decimal(10,2) DEFAULT 0.00,
  `requested_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `processed_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`return_id`),
  UNIQUE KEY `return_number` (`return_number`),
  KEY `order_id` (`order_id`),
  KEY `customer_id` (`customer_id`),
  KEY `ticket_id` (`ticket_id`),
  CONSTRAINT `return_requests_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  CONSTRAINT `return_requests_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE CASCADE,
  CONSTRAINT `return_requests_ibfk_3` FOREIGN KEY (`ticket_id`) REFERENCES `customer_support_tickets` (`ticket`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `review_responses`;
CREATE TABLE `review_responses` (
  `response_id` int(11) NOT NULL AUTO_INCREMENT,
  `review_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `response` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`response_id`),
  KEY `idx_responses_review` (`review_id`),
  KEY `idx_responses_business` (`business_id`),
  CONSTRAINT `fk_responses_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`business_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_responses_review` FOREIGN KEY (`review_id`) REFERENCES `reviews` (`review_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `review_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `helpful_count` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`review_id`),
  UNIQUE KEY `uk_reviews_customer_product` (`customer_id`,`product_id`),
  KEY `idx_reviews_product` (`product_id`),
  KEY `idx_reviews_status` (`status`),
  KEY `idx_reviews_rating` (`rating`),
  CONSTRAINT `fk_reviews_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_reviews_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chk_reviews_rating` CHECK (`rating` >= 1 and `rating` <= 5)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `reviews` VALUES
('1', '5', '48', '3', 'goods', 'approved', '0', '2026-06-07 21:21:59', '2026-06-07 21:24:25'),
('2', '5', '43', '3', 'good', 'approved', '0', '2026-06-07 21:22:28', '2026-06-07 21:24:20'),
('3', '5', '45', '3', 'good', 'approved', '0', '2026-06-11 00:18:28', '2026-06-11 18:51:17'),
('4', '5', '56', '3', 'goods performance, looking and better product', 'approved', '0', '2026-06-18 23:41:18', '2026-06-18 23:45:40'),
('5', '5', '42', '3', 'goods', 'approved', '0', '2026-06-19 15:36:15', '2026-06-19 15:43:01'),
('6', '5', '41', '3', 'goods', 'pending', '0', '2026-06-19 15:37:11', '2026-06-19 15:37:11');

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text NOT NULL,
  `setting_group` varchar(50) NOT NULL DEFAULT 'general',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `unique_key_group` (`setting_key`,`setting_group`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `settings` VALUES
('1', 'smtp_host', 'smtp.gmail.com', 'email', '2026-06-21 20:13:11', '2026-06-21 20:13:11'),
('2', 'smtp_port', '587', 'email', '2026-06-21 20:13:11', '2026-06-21 20:13:11'),
('3', 'smtp_encryption', 'tls', 'email', '2026-06-21 20:13:11', '2026-06-21 20:13:11'),
('4', 'smtp_username', 'admin@unksystem.com', 'email', '2026-06-21 20:13:11', '2026-06-21 20:13:11'),
('5', 'smtp_password', 'Twaha@2004', 'email', '2026-06-21 20:13:11', '2026-06-21 20:13:11'),
('6', 'from_email', 'noreply@unksystem.com', 'email', '2026-06-21 20:13:11', '2026-06-21 20:13:11'),
('7', 'from_name', 'UNK System', 'email', '2026-06-21 20:13:11', '2026-06-21 20:13:11'),
('8', 'enable_notifications', '1', 'email', '2026-06-21 20:13:11', '2026-06-21 20:13:11'),
('9', 'order_confirmation', '1', 'email', '2026-06-21 20:13:11', '2026-06-21 20:13:11'),
('10', 'delivery_notification', '1', 'email', '2026-06-21 20:13:11', '2026-06-21 20:13:11'),
('11', 'payment_receipt', '1', 'email', '2026-06-21 20:13:11', '2026-06-21 20:13:11'),
('12', 'welcome_email', '1', 'email', '2026-06-21 20:13:11', '2026-06-21 20:13:11'),
('13', 'password_reset', '1', 'email', '2026-06-21 20:13:12', '2026-06-21 20:13:12');

DROP TABLE IF EXISTS `stock_history`;
CREATE TABLE `stock_history` (
  `history_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `old_quantity` int(11) NOT NULL,
  `new_quantity` int(11) NOT NULL,
  `change_amount` int(11) NOT NULL,
  `action_type` varchar(50) DEFAULT 'update',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`history_id`),
  KEY `idx_stock_product` (`product_id`),
  KEY `idx_stock_business` (`business_id`),
  KEY `idx_stock_created` (`created_at`),
  CONSTRAINT `fk_stock_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`business_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_stock_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `stock_history` VALUES
('1', '56', '11', '9', '15', '6', 'manual_update', 'stock adjustment', '2026-06-18 23:46:31'),
('2', '51', '10', '12', '13', '1', 'manual_update', 'stock adjustment', '2026-06-20 09:49:16'),
('3', '60', '7', '6', '16', '10', 'manual_update', 'stock adjustment', '2026-06-29 19:23:56');

DROP TABLE IF EXISTS `support_replies`;
CREATE TABLE `support_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `reply_by_type` enum('customer','business','delivery','admin') NOT NULL,
  `reply_by_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ticket` (`ticket_id`),
  KEY `idx_is_read` (`is_read`),
  CONSTRAINT `support_replies_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `support_tickets`;
CREATE TABLE `support_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_no` varchar(20) NOT NULL,
  `created_by_type` enum('customer','business','delivery','admin') NOT NULL,
  `created_by_id` int(11) NOT NULL,
  `assigned_to_type` enum('customer','business','delivery','admin') DEFAULT NULL,
  `assigned_to_id` int(11) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `category` varchar(50) DEFAULT 'general',
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `status` enum('open','in_progress','resolved','closed') DEFAULT 'open',
  `attachment` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_no` (`ticket_no`),
  KEY `idx_created` (`created_by_type`,`created_by_id`),
  KEY `idx_assigned` (`assigned_to_type`,`assigned_to_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `support_tickets_temp`;
CREATE TABLE `support_tickets_temp` (
  `ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `ticket_number` varchar(20) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `status` enum('open','in_progress','resolved','closed') DEFAULT 'open',
  `attachment` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ticket_id`),
  UNIQUE KEY `ticket_number` (`ticket_number`),
  KEY `customer_id` (`customer_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `support_tickets_temp_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE CASCADE,
  CONSTRAINT `support_tickets_temp_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `system_logs`;
CREATE TABLE `system_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_type` enum('admin','business','customer','delivery') DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created` (`created_at`),
  KEY `idx_user_type` (`user_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_group` varchar(50) DEFAULT 'general',
  `setting_type` enum('text','number','boolean','json','textarea','select') DEFAULT 'text',
  `is_public` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `idx_setting_key` (`setting_key`),
  KEY `idx_setting_group` (`setting_group`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `system_settings` VALUES
('1', 'site_name', 'UNK System', 'general', 'text', '0', '2026-06-21 19:01:17', '2026-07-01 02:45:00'),
('2', 'site_tagline', 'Ulipo ni Kariakoo', 'general', 'text', '0', '2026-06-21 19:01:17', '2026-07-01 02:45:00'),
('3', 'site_email', 'info@unksystem.com', 'general', 'text', '0', '2026-06-21 19:01:17', '2026-07-01 02:45:00'),
('4', 'site_phone', '+255 615 215 404', 'general', 'text', '0', '2026-06-21 19:01:17', '2026-07-01 02:45:00'),
('5', 'site_address', 'Kariakoo Market, Dar es Salaam, Tanzania', 'general', 'text', '0', '2026-06-21 19:01:17', '2026-07-01 02:45:01'),
('6', 'site_currency', 'TSh', 'general', 'text', '0', '2026-06-21 19:01:17', '2026-07-01 02:45:01'),
('7', 'timezone', 'Africa/Dar_es_Salaam', 'general', 'text', '0', '2026-06-21 19:01:17', '2026-07-01 02:45:01'),
('8', 'date_format', 'Y-m-d', 'general', 'text', '0', '2026-06-21 19:01:17', '2026-07-01 02:45:01'),
('9', 'time_format', 'H:i:s', 'general', 'text', '0', '2026-06-21 19:01:17', '2026-07-01 02:45:01'),
('82', 'maintenance_mode', '0', 'system', 'boolean', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:39'),
('83', 'allow_registration', '1', 'system', 'boolean', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:39'),
('84', 'require_email_verification', '1', 'system', 'boolean', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:39'),
('85', 'require_phone_verification', '0', 'system', 'boolean', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:39'),
('86', 'enable_guest_checkout', '1', 'system', 'boolean', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:39'),
('87', 'enable_reviews', '1', 'system', 'boolean', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:39'),
('88', 'enable_wishlist', '1', 'system', 'boolean', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:40'),
('89', 'enable_comparison', '1', 'system', 'boolean', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:40'),
('90', 'max_upload_size', '5', 'system', 'number', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:40'),
('91', 'allowed_file_types', 'jpg,jpeg,png,gif,pdf,doc,docx', 'system', 'text', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:40'),
('92', 'image_quality', '80', 'system', 'number', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:40'),
('93', 'thumbnail_width', '300', 'system', 'number', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:40'),
('94', 'thumbnail_height', '300', 'system', 'number', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:40'),
('95', 'items_per_page', '15', 'system', 'number', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:40'),
('96', 'max_cart_items', '50', 'system', 'number', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:40'),
('97', 'session_timeout', '3600', 'system', 'number', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:40'),
('98', 'max_login_attempts', '5', 'system', 'number', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:41'),
('99', 'lockout_time', '15', 'system', 'number', '0', '2026-06-21 19:11:02', '2026-06-21 19:14:41'),
('100', 'enable_ssl', '1', 'system', 'boolean', '0', '2026-06-21 19:11:03', '2026-06-21 19:14:41'),
('101', 'enable_cache', '1', 'system', 'boolean', '0', '2026-06-21 19:11:03', '2026-06-21 19:14:41'),
('102', 'cache_duration', '3600', 'system', 'number', '0', '2026-06-21 19:11:03', '2026-06-21 19:14:41'),
('103', 'enable_debug_mode', '0', 'system', 'boolean', '0', '2026-06-21 19:11:03', '2026-06-21 19:14:41'),
('104', 'log_errors', '1', 'system', 'boolean', '0', '2026-06-21 19:11:03', '2026-06-21 19:14:41'),
('105', 'auto_backup_enabled', '1', 'backup', 'text', '0', '2026-06-21 19:27:51', '2026-06-29 11:29:33'),
('106', 'backup_frequency', 'daily', 'backup', 'text', '0', '2026-06-21 19:27:51', '2026-06-29 11:29:34'),
('107', 'backup_time', '11:01', 'backup', 'text', '0', '2026-06-21 19:27:51', '2026-06-29 11:29:34'),
('108', 'backup_type', 'full', 'backup', 'text', '0', '2026-06-21 19:27:51', '2026-06-29 11:29:34'),
('109', 'max_backups', '10', 'backup', 'text', '0', '2026-06-21 19:27:51', '2026-06-29 11:29:34'),
('110', 'backup_retention_days', '30', 'backup', 'text', '0', '2026-06-21 19:27:52', '2026-06-29 11:29:34'),
('111', 'backup_location', '../backups/', 'backup', 'text', '0', '2026-06-21 19:27:52', '2026-06-29 11:29:34'),
('112', 'compress_backups', '1', 'backup', 'text', '0', '2026-06-21 19:27:52', '2026-06-29 11:29:34'),
('113', 'email_backup_notifications', '1', 'backup', 'text', '0', '2026-06-21 19:27:52', '2026-06-29 11:29:34'),
('114', 'backup_email', 'admin@unksystem.com', 'backup', 'text', '0', '2026-06-21 19:27:52', '2026-06-29 11:29:34');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `role` enum('admin','business','customer','delivery') NOT NULL,
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uk_users_email` (`email`),
  KEY `idx_users_role` (`role`),
  KEY `idx_users_status` (`status`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_phone` (`phone`),
  KEY `idx_users_role_status` (`role`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` VALUES
('1', 'Mohamed Mussa', 'admin@unksystem.com', '$2y$10$kHxvkyOoMhmfEV.5ukaRY.zIoJgsBIOilkWwCNBxE1KArZzXYpQ2O', '0615215404', 'admin', 'active', '2026-07-02 10:27:56', '2026-06-07 08:30:16', '2026-07-02 10:27:56'),
('19', 'Mwamini Nyoni', 'mwaminnyoni@gmail.com', '$2y$10$DYckD.D8TJJKuYWmeHXpCOLwujtzrltDpoA0.q6n6yD1WGwQE6EhS', '0767708012', 'business', 'active', '2026-07-01 17:45:13', '2026-06-01 00:32:03', '2026-07-01 17:45:13'),
('20', 'Twaha Mohamed', 'albinokh425@gmail.com', '$2y$10$y1AWlxkc8JQxSaQl4xBaf.cYCpazly9i1ysu627lQlMYLsfScQhlG', '0617666477', 'customer', 'active', '2026-07-01 19:01:05', '2026-06-01 00:50:57', '2026-07-01 19:01:05'),
('23', 'FURAHA SADOCK', 'furahasadock@gmail.com', '$2y$10$boyK6TRmDsp6lhqHThaImuv24XBVQ9egX8auv5zff8PjfdwP1L9ei', '0765071806', 'customer', 'active', '2026-06-01 20:08:43', '2026-06-02 06:07:49', '2026-06-02 06:08:43'),
('25', 'Mohamed Ajemy', 'mohamed@gmail.com', '$2y$10$KNaIDvEIxOThE9YSqOYO1OlgroGuwaPem5HH.E0MnvxSFsjHaoa9C', '0617666478', 'delivery', 'active', '2026-07-01 21:12:16', '2026-06-02 22:11:43', '2026-07-01 21:12:16'),
('26', 'Omary Omary', 'omaryomary@gmail.com', '$2y$10$6SmwNg/uF1NG6CxcFO/hf.btAJjSjEkn/j3gOdjmyYLiKW7KzQ9oK', '0633424315', 'delivery', 'active', '2026-06-29 17:38:44', '2026-06-02 23:43:18', '2026-06-29 17:38:44'),
('28', 'Mohamed Twaha', 'twahakh425@gmail.com', '$2y$10$A8e4KVoDKqrwAPjS.G.u7usx2PwfhL/3fccfnncjjZ.wQ5sXLEsBG', '0799051862', 'business', 'active', '2026-07-01 14:28:44', '2026-06-03 03:22:59', '2026-07-01 14:28:44'),
('30', 'Pendael Jumbe', 'jumbependael106@gmail.com', '$2y$10$teJQio37XJxkTMB8VN2bMesekdyQg453yeUfMbya8kBirth/jIcQ6', '0744319731', 'customer', 'active', NULL, '2026-06-10 16:16:12', '2026-06-10 16:16:12'),
('31', 'Paulo Sanii', 'paulohhari991@gmail.com', '$2y$10$eIB8CwJjL93KCdAVpRCTfOh7qs9oJKJOZYc17VXuSWJaBJHH1XXgO', '0764080102', 'business', 'active', '2026-06-18 23:44:06', '2026-06-10 16:26:43', '2026-06-21 01:15:06'),
('32', 'samsung ultra', 'alx@gmail.com', '$2y$10$r04AlAT2ex/fAKaEmBhct.Veu36zKE8tuN84nCxldbjhnrHxs0g3e', '0617666476', 'customer', 'active', '2026-06-12 02:02:43', '2026-06-12 12:02:11', '2026-06-12 12:02:43'),
('33', 'Abdulrazaq Jafar', 'abdulrazaqjafar66@gmail.com', '$2y$10$ytP68OR37XTHF1X5CU0zjOUl0kzv0ChlZU0MHTXJx19stvUjwFVIG', '0679014566', 'customer', 'active', NULL, '2026-06-12 13:02:07', '2026-06-12 13:02:07');

DROP TABLE IF EXISTS `wishlist`;
CREATE TABLE `wishlist` (
  `wishlist_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`wishlist_id`),
  UNIQUE KEY `uk_wishlist_customer_product` (`customer_id`,`product_id`),
  KEY `idx_wishlist_customer` (`customer_id`),
  KEY `idx_wishlist_product` (`product_id`),
  CONSTRAINT `fk_wishlist_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wishlist_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `wishlist` VALUES
('20', '5', '64', '2026-06-30 02:41:22'),
('22', '5', '65', '2026-06-30 02:47:48');

SET FOREIGN_KEY_CHECKS=1;
